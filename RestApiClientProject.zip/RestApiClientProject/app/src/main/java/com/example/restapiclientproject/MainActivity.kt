package com.example.restapiclientproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import retrofit2.Call
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private val list = ArrayList<FilmResponse>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        readFilms()
        createFilms()
    }
    private fun createFilms(){
        RetrofitClient.instance.createFilm(
            "https://image.tmdb.org/t/p/w600_and_h900_bestv2/npOnzAbLh6VOIu3naU5QaEcTepo.jpg",
            "Pemrograman Mobile",
            "2020",
            "Ini adalah mata kuliah yang memusingkannn").enqueue(object : retrofit2.Callback<CreateFilmResponse>{
            override fun onFailure(call: Call<CreateFilmResponse>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Failed to create data", Toast.LENGTH_LONG).show()
            }

            override fun onResponse(
                call: Call<CreateFilmResponse>,
                response: Response<CreateFilmResponse>
            ) {
                Toast.makeText(this@MainActivity, "Data Succesfully Created", Toast.LENGTH_LONG).show()
            }
            })
        )
        private fun readFilms(){
            rvFilms.setHasFixedSize(true)
            rvFilms.layoutManager = LinearLayoutManager(this) RetrofitClient.instance.getFilms().enqueue(object : retrofit2.Callback<ArrayList<FilmResponse>>(
                override fun onFailure(call: Call<ArrayList<FilmResponse>>, t:Throwable){
                    Toast.makeText(this@MainActivity, "Failed to read data", Toast.LENGTH_LONG).show()
                }
                override fun onResponse(
                    call: Call<ArrayList<FilmResponse>>,
                    response: Response<ArrayList<FilmResponse>>
                ){
                    response.body()?.let {
                        list.addAll(it)
                    }
                    val adapter = FilmsAdapter(list)
                    rvFilms.adapter = adadpter
                }
            )}
    }
}